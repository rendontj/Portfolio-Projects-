"""
___________________________________________________________________________
* Python Program Name: Problem 1
___________________________________________________________________________
* Description:

  The main purpose of this python module is to implement RKF45 to be applied
  to the given IVP.

____________________________________________________________________________
* Taylor Rendon
* 3 May 2022
* Python 3
___________________________________________________________________________

"""


def f(t, y):  # since f(t,y(t)) = f(y(t)
    lam = 1 + 20j  # for problem 6 and 7, otherwise set to None as a placeholder for a user choice of λ.
    return lam * y  # note j = \sqrt(-1)


def RKF45(t0, t1, y0, f, n):  # Here we perform the necessary RKF45 calculations
    vt = [0] * (n + 1)
    vw = [0] * (n + 1)
    h = (t1 - t0) / float(n)

    vt[0] = t = t0
    vw[0] = y = y0

    for i in range(1, n + 1):
        k1 = h * f(t, y)
        k2 = h * f(t + 0.5 * h, y + k1 / 2)
        k3 = h * f(t + 0.5 * h, y + k2 / 2)
        k4 = h * f(t + h, y + k3)

        vt[i] = t0 + i * h
        vw[i] = y = (y + (1 / 6) * (k1 + 2 * k2 + 2 * k3 + k4))

    return vt, vw
