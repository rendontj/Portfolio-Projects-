import matplotlib.pyplot as plt
import numpy as np
import P4Func as p4f

"""
___________________________________________________________________________
* Python Program Name: Problem 4 and 5 (and the first part of 6)
___________________________________________________________________________
* Description:

  Please see the written portion of number 5 in the .pdf file

  The main purpose of this python module is to plot the implicit equation 
  |Q(x+yi)| = 1 over [-3, 3] with the desired hλ point for problem 6. 

____________________________________________________________________________
* Taylor Rendon
* 3 May 2022
* Python 3
___________________________________________________________________________

"""
xrange = np.linspace(-3, 3)
yrange = np.linspace(-3, 3)
X, Y = np.meshgrid(xrange, yrange)

F = p4f.F(X, Y)
G = 1
plt.xlabel('Re(hλ)')
plt.ylabel('Im(hλ)')
plt.title('4th Order Stability Region')
plt.contour(X, Y, (F - G), [0])
plt.plot(0.1, 2, 'ro', label='hλ = 0.1 + 2i')
plt.legend()
plt.show()
