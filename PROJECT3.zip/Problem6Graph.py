import matplotlib.pyplot as plt
import Problem1 as p1

"""
___________________________________________________________________________
* Python Program Name: Problem 6 Graph 
___________________________________________________________________________
* Description:

  Note that the first part of question 6 is 
  answered in Problem4&5.py. Here, provide the graph for the written portion 
  of question 6. Please See the written portion for question 6 in the .pdf 
  file. 

  The main purpose of this python module is to visualize the convergence of 
  the implemented RKF45 method. 

____________________________________________________________________________
* Taylor Rendon
* 3 May 2022
* Python 3
___________________________________________________________________________

"""

vt, vw = p1.RKF45(0, 10, 1, p1.f, 100)  # note h = 0.1 <=> n = 100
plt.plot(vt, vw)
plt.xlabel('t')
plt.ylabel('w')
plt.title('4th Order Method Graphical Convergence')
plt.show()
