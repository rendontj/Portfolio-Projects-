import Problem1 as p1
import numpy as np
import matplotlib.pyplot as plt

"""
___________________________________________________________________________
* Python Program Name: Problem 7
___________________________________________________________________________
* Description:

  The main purpose of this python module is to answer question 7 by plotting
  the real part of the solution and the numerical approximation on the same 
  plot for comparison. 
  
  Be sure to read the comment at the end of this module 
  regarding the choice of h. 

____________________________________________________________________________
* Taylor Rendon
* 3 May 2022
* Python 3
___________________________________________________________________________

"""


def realExact(t: list) -> list:  # This function defines the real part of the exact solution
    image = []
    for x in t:
        y = np.exp(x) * np.cos(20 * x)
        image.append(y)
    return image


vt, vw = p1.RKF45(0, 10, 1, p1.f, 1000)  # n = 1000 <=> h = 0.01

plt.plot(vt, realExact(vt), '-b', label='Real part of exact solution for given h and λ')
plt.plot(vt, vw, '-r', label='Approximation')
plt.legend()
plt.show()

#  Note: while the book suggests we use h = 0.05 for the fixed lambda, we find that tweaking h to be 0.01 works much better.
