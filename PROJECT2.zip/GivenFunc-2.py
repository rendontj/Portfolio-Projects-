"""
___________________________________________________________________________
* Python Program Name: Problem 1
___________________________________________________________________________
* Description: This python module implements the function given in problem 1.
  This allows us to organize our code so our main problem 1 module is not
  cluttered.
___________________________________________________________________________
* Taylor Rendon
* 8 April 2022
* Python 3
___________________________________________________________________________

"""


def f(t, y):
    a = -3 * t * (y ** 2)
    b = 1 / (1 + (t ** 3))
    return a + b


"""
to a mathematician this function defined above may seem kind of strange - isn't 
y a function as well and shouldn't we be writing y(t) in its place? The answer is
yes, but recall that this function is part of a pair: an initial value problem. We 
are approximating y(t) starting from the initial condition, hence the treatment of 
notation above. 
"""
