from matplotlib import pyplot as plt
import GivenFunc as gf

"""
___________________________________________________________________________
* Python Program Name: Problem 1, 2, 3 and 4. (written portion: .pdf file)
___________________________________________________________________________
* Description: 

  The main purpose of this python module is to implement RKF45 
  so it may be applied to the given IVP. 
  
  In addition, this module also plots the RKF45 approximation versus the 
  constructed vector t. Similarly, we also plot the global error vs. t. 
  
  Lastly, since we are given the exact solution to the IVP, we use this to 
  calculate the error at each t_i (component of t) and store these errors 
  in a vector (dubbed the name 'errorvec' which we plot against a sublist of 
  t (since t is a list "at heart").
___________________________________________________________________________
* Taylor Rendon 
* 8 April 2022
* Python 3
___________________________________________________________________________

"""
#  I know it's kinda ugly, but here we declare the necessary variables and constants.
a = 0
b = 5
y0 = 0
t0 = 0
TOL = 5e-7
hMax = 0.25
hMin = 0.01
h = hMax

vect = [0]  # note that the first entry in this vector (list) and the vector below are given by the specifies initial conditions.
vectw = [0]
vecth = []

t = t0
y = y0

while t < b:  # here we perform the necessary RKF45 calculations with the adaptive time stepping method discussed in class.
    vecth.append(h)
    k1 = h * gf.f(t, y)
    k2 = h * gf.f(t + (1 / 4) * h, y + (1 / 4) * k1)
    k3 = h * gf.f(t + (3 / 8) * h, y + (3 / 32) * k1 + (9 / 32) * k2)
    k4 = h * gf.f(t + (12 / 13) * h, y + (1932 / 2197) * k1 - (7200 / 2197) * k2 + (7296 / 2197) * k3)
    k5 = h * gf.f(t + h, y + (439 / 216) * k1 - 8 * k2 + (3680 / 513) * k3 - (845 / 4104) * k4)
    k6 = h * gf.f(t + (1 / 2) * h,
                  y - (8 / 27) * k1 + 2 * k2 - (3544 / 2565) * k3 + (1859 / 4104) * k4 - (11 / 40) * k5)

    er = (1 / h) * ((1 / 360) * k1 - (128 / 4275) * k3 - (2197 / 75240) * k4 + (1 / 50) * k5 + (2 / 55) * k6)
    q = (TOL / (2 * abs(er))) ** (1 / 4)

    h = q * h

    if h < hMin:
        h = hMin
    if h > hMax:
        h = hMax

    t = t + h
    vect.append(t)
    y = y + ((16 / 135) * k1 + (6656 / 12825) * k3 + (28561 / 56430) * k4 - (9 / 50) * k5 + (2 / 55) * k6)
    vectw.append(y)


def exact(
        x: list) -> list:  # this notation is used to specify that this function eats a list and spits out a list. DO NOT feed it a number.
    image = []
    for t in x:
        y = t / (1 + (t ** 3))
        image.append(y)

    return image  # so this function returns the image of the exact solution.


#  Below, we construct all the necessary plots.

exactSolution = exact(vect)  # feed the exact solution function the vector t we obtained from the RKF45 calculations.
plt.plot(vect, vectw)
plt.plot(vect, exactSolution)
plt.title("Problem 2: Graph of Approximation to ODE and "
          "Exact Solution vs. Time")
plt.xlabel('t')
plt.ylabel('y(t)')
plt.plot(vect, exactSolution, '-b', label='Exact Solution')
plt.plot(vect, vectw, '-r', label='Approximation')
plt.legend()
plt.show()  # while it's not required, I plotted the exact solution along with the approximation for comparison.

errorvec = []
zipped = list(zip(vect, vectw))  # here, we zip together these two lists and create a list of tuples. This is easier to iterate over than using two for loops or something worse.
for t, y in zipped:
    z = y - (t / (1 + (t ** 3)))
    errorvec.append(z)

plt.xlabel('t')
plt.ylabel('Approximate - Exact')
plt.title("Problem 3: Global Error")
plt.plot(vect[0:len(errorvec)], errorvec)  # you will notice we have to trim down the domain here and below since python requires the two lists to have the same shape for plotting.
plt.show()

plt.xlabel('t')
plt.ylabel('Step Vector h')
plt.title("Problem 4: Graph of h vs. time")
plt.plot(vect[0:len(vecth)], vecth)
plt.show()
