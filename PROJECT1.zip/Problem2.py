import numpy as np
import Vector as vt

'''
___________________________________________________________________________
* Python Program Name: Problem2. 
___________________________________________________________________________
* Description: In order to approximate the function at multiple points in 
  the interval [0, π], we alter the code from Neville's iteration such that 
  within the program we create a vector (using the Vector module) x of 
  4n + 1 points [0, π] with x_0 = 0, x_4n = π, and find the approximation P_{n}(x) 
  to sin(x) at each of these points. The output of this program is these 
  approximations in a single vector y_{int} and the corresponding (vector) x. 

___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________
 
'''


def neville(nodes):
    datax = []
    datay = []

    vec = vt.vector(nodes)  # instead of using a single point, we insert a vector of points to evaluate at.

    for p in np.linspace(0, np.pi):
        datax.append(p)
        y = np.sin(p)
        datay.append(y)

    n = nodes + 1
    poly = n * [0]

    y_int = []
    h = 0
    while len(y_int) < len(vec):  # this while loop allows us to perform the iteration for multiple values of x
        x = vec[h]
        for k in range(n):
            for j in range(n - k):
                if k == 0:
                    poly[j] = datay[j]
                else:
                    poly[j] = ((x - datax[j + k]) * poly[j] +
                               (datax[j] - x) * poly[j + 1]) / (datax[j] - datax[j + k])
        if poly[0] == -0.0:  # While this may be redundant, I put it here just in case since -0.0 kept showing up in the y_int vector.
            y_int.append(np.abs(poly[0]))
        else:
            y_int.append(poly[0])
        h = h + 1
    return vec, y_int
