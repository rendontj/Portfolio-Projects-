import numpy as np
import Problem6 as p6
from matplotlib import pyplot as plt

'''
___________________________________________________________________________
* Python Program Name: Problem8.
___________________________________________________________________________
* Description: This script answers question 8. Since we fix the range 
  of values that n takes on, we leave this file as a script and not a re-
  usable function for different values of n than desired. 

Problem 8 user notes: The plots are not produced all at once, you must close 
the current graph to advance to the next. As well, see written portion in .pdf
file for the rest of the answer. 
___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________

'''

final_error_vector = []

for n in range(1, 21):
    y_exact = []
    tempx, y_int = p6.neville1(n)
    for j in tempx:
        d = 1 + 25 * j**2
        y = 1/d
        y_exact.append(y)
    i = 0
    error_vector = []
    while i < len(y_exact):
        error_comp = np.abs(y_exact[i] - y_int[i])
        error_vector.append(error_comp)
        i = i + 1
    max_comp = max(error_vector)
    final_error_vector.append(max_comp)

y_axis = final_error_vector
x_axis = range(1, 21)
plt.title('Problem 8: Error Portion')
plt.xlabel('n')
plt.ylabel('Maximum Error for Each n')
plt.semilogy(x_axis, y_axis, '.')
plt.show()


def f(a):  # we construct a python function for the mathematical function f (it's much easier plotting this way).
    image = []
    for k in a:
        dd = 1 + 25 * k**2
        h = 1/dd
        image.append(h)
    return image


x, y = p6.neville1(2)  # n = 2 is the optimal n for the smallest error, so we use it here to plot the exact solution and y_int for this value of n
plt.title('Problem 5: Graph of f(x) & y_int For n = 2')
plt.plot(x, f(x), '-r', label='f(x)')
plt.plot(x, y, '-b', label='y_int')
plt.legend()
plt.show()
