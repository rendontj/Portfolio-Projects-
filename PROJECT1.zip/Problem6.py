import numpy as np


'''
___________________________________________________________________________
* Python Program Name: Problem6. 
___________________________________________________________________________
* Description: In order to approximate the function at multiple points in 
  the interval [-1, 1], we alter the code from Neville's iteration such that 
  within the program we create a vector from the interval [-1.1], and find 
  the approximation P_{n}(x) to 1 / 1 + 25x^2 at each of these points. 
  The output of this program is these approximations in a single vector y_{int} 
  and the corresponding (vector) x. 

___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________
 
'''


def neville1(nodes):
    datax = []
    datay = []

    vec = np.linspace(-1, 1)  # note we don't use the vector function from before since pi is outside this domain.

    for p in np.linspace(-1, 1):
        datax.append(p)
        d = 1 + 25 * p**2
        y = 1/d
        datay.append(y)

    n = nodes + 1
    poly = n * [0]

    y_int = []
    h = 0
    while len(y_int) < len(vec):
        x = vec[h]
        for k in range(n):
            for j in range(n - k):
                if k == 0:
                    poly[j] = datay[j]
                else:
                    poly[j] = ((x - datax[j + k]) * poly[j] +
                               (datax[j] - x) * poly[j + 1]) / (datax[j] - datax[j + k])
        if poly[0] == -0.0:
            y_int.append(np.abs(poly[0]))
        else:
            y_int.append(poly[0])
        h = h + 1
    return vec, y_int
