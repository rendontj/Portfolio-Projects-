import Problem2 as p2
from matplotlib import pyplot as plt

"""
___________________________________________________________________________
* Python Program Name: Problem3
___________________________________________________________________________
* Description: This script plots y_int versus x for several n values, 
  n = 1, 2, 3, 5, 10.

Problem 3 user notes: The plots are not produced all at once, you must close 
the current graph to advance to the next for every n in the vector several. 
___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________
"""


several = [1, 2, 3, 5, 10]

for n in several:  # This for loop makes constructing multiple plots more efficient.
    x, y = p2.neville(n)
    plt.title('n = {n}'.format(n=n))  # the .format() method (along with a keyword parameter) is used to make the title of each plot for appropriate n.
    plt.xlabel('Corresponding x')
    plt.ylabel('y_int ')
    plt.plot(x, y)
    plt.show()
