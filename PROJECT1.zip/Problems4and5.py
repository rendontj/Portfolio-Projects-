import numpy as np
import Problem2 as p2
from matplotlib import pyplot as plt


'''
___________________________________________________________________________
* Python Program Name: Problems4and5.
___________________________________________________________________________
* Description: This script answers questions 4 and 5. Since we fix the range 
  of values that n takes on, we leave this file as a script and not a re-
  usable function for different values of n than desired. 

Problem 5 user notes: The plots are not produced all at once, you must close 
the current graph to advance to the next. As well, see written portion in .pdf
file for the rest of the answer. 
___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________

'''

final_error_vector = []

for n in range(1, 21):  # please note that the list range does not include the last endpoint, so if we want n = 20 we need to place 21 as the endpoint.
    y_exact = []
    tempx, y_int = p2.neville(n)
    for j in tempx:  # here we construct y_exact for "exact" values of sin(x).
        y = np.sin(j)
        y_exact.append(y)
    i = 0
    error_vector = []
    while i < len(y_exact):  # here we construct a vector containing the maximum error for each n.
        error_comp = np.abs(y_exact[i] - y_int[i])
        error_vector.append(error_comp)
        i = i + 1
    max_comp = max(error_vector)
    final_error_vector.append(max_comp)

y_axis = final_error_vector
x_axis = range(1, 21)
plt.title('Problem 5: Error Portion')
plt.xlabel('n')
plt.ylabel('Maximum Error for Each n')
plt.semilogy(x_axis, y_axis, '.')
plt.show()  # this shows the plot for final_error_vector vs. n (log base 10 on the y-axis and linear scale on the x-axis)

x, y = p2.neville(11)  # n = 11 is the optimal n for the smallest error, so we use it here to plot the exact solution and y_int for this value of n
plt.title('Problem 5: Graph of sin(x) & y_int For n = 11')
plt.plot(x, np.sin(x), '-r', label='sin(x)')
plt.plot(x, y, '-b', label='y_int')
plt.legend()
plt.show()
