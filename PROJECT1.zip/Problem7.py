import Problem6 as p6
from matplotlib import pyplot as plt

"""
___________________________________________________________________________
* Python Program Name: Problem6
___________________________________________________________________________
* Description: This script plots y_int versus x for several values of n. 

Problem 7 user notes: The plots are not produced all at once, you must close 
the current graph to advance to the next for every n in the vector several. 
___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________
"""

several = [1, 2, 3, 5, 10, 12, 14, 15, 21]

for n in several:
    x, y = p6.neville1(n)
    plt.title('n = {n}'.format(n=n))
    plt.xlabel('Corresponding x')
    plt.ylabel('y_int ')
    plt.plot(x, y)
    plt.show()
