import numpy as np

'''
___________________________________________________________________________
* Python Program Name: NevillesAlg (Problem 1).
___________________________________________________________________________
* Description: This script applies Neville’s iteration to approximate f(x) = sin(x) 
  at any given x in [0, π] using n + 1 evenly spaced nodes in [0, π]. The output is 
  an approximation to sin(x) using a Lagrange polynomial of degree n.

___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________

'''


def neville(x, nodes):
    datax = []
    datay = []
    for p in np.linspace(0, np.pi):  # here we construct the domain and range for the function we want to interpolate
        datax.append(p)
        y = np.sin(p)
        datay.append(y)

    n = nodes + 1
    poly = n * [0]  # this is here just so we don't start with an empty list
    for k in range(n):  # this latter of for loops provides the calculations for Neville's iteration
        for j in range(n - k):
            if k == 0:
                poly[j] = datay[j]
            else:
                poly[j] = ((x - datax[j + k]) * poly[j] +
                           (datax[j] - x) * poly[j + 1]) / (datax[j] - datax[j + k])

    return poly[0]  # the value of the degree n+1 polynomial at the desired interpolating point
