import numpy as np

'''
___________________________________________________________________________
* Python Program Name: Vector (for implementation into problem 2).
___________________________________________________________________________
* Description: code that constructs the vector x with 4n+1 entries for
problem 2. Implemented in Problem2.py

___________________________________________________________________________
* Taylor Rendon 
* 3/4/22
* Python 3
___________________________________________________________________________

'''


def vector(n):
    vectorx = []
    i = 0
    for x in np.linspace(0, np.pi):  # here we are constructing the vector from the given interval
        if i >= 4 * n + 1:  # this behaves the same way as: if i > 4 * n:
            break
        vectorx.append(x)
        i = i + 1
    vectorx[0] = 0
    vectorx[len(vectorx) - 2] = np.pi
#  recall that we needed to assign x_0 = 0 and x_{4n} = pi
    return vectorx
